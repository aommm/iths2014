var app = angular.module("TestApp", ["ngRoute"]);
app.config(["$routeProvider", function($routeProvider){
	$routeProvider.when("/", {});
	$routeProvider.when("/space", {
		templateUrl: "space.html"
	});
	$routeProvider.otherwise({
		redirectTo: "/"
	});
}]);